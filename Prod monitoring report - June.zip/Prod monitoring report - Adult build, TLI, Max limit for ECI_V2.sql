WITH latest_hdr AS (
    SELECT app_id, reference_no,owner_client_no,insured_client_no,mre_case_id, updated_dt,
           ROW_NUMBER() OVER (PARTITION BY app_id ORDER BY updated_dt DESC) AS rn
    FROM STP_TRANSACTION_HDR
),
latest_stpautoappdo AS (
    SELECT app_id, response_data, updated_dt,
           ROW_NUMBER() OVER (PARTITION BY app_id ORDER BY updated_dt DESC) AS rn
    FROM stp_transaction_dtl
    WHERE activity_cd = 'STPAUTOAPPDO'
),
latest_stpupdium AS (
    SELECT app_id, request_data,
           ROW_NUMBER() OVER (PARTITION BY app_id ORDER BY updated_dt DESC) AS rn
    FROM stp_transaction_dtl
    WHERE activity_cd = 'STPUPDDRTIUM'
)

SELECT hdr.app_id, hdr.reference_no,hdr.owner_client_no,hdr.insured_client_no ,hdr.mre_case_id,hdr.updated_dt,
--IS_OWNER LIFE 1 & LIFE 2----
NVL(JSON_VALUE(a.response_data, '$.dynamicOrchestratorResponse.lives[0].attributes.attributes.IS_OWNER'),'N/A') AS IS_OWNER_LIFE1,
NVL(JSON_VALUE(a.response_data, '$.dynamicOrchestratorResponse.lives[1].attributes.attributes.IS_OWNER'),'N/A') AS IS_OWNER_LIFE2,
--IS_PRIMARY_INSURED----
NVL(JSON_VALUE(a.response_data, '$.dynamicOrchestratorResponse.lives[0].attributes.attributes.IS_PRIMARY_INSURED'),'N/A') AS IS_PRIMARY_INSURED,
 --IS_INSURED LIFE 1 & LIFE 2--
NVL(JSON_VALUE(a.response_data, '$.dynamicOrchestratorResponse.lives[0].attributes.attributes.IS_INSURED'),'N/A') AS IS_INSURED_LIFE1,
NVL(JSON_VALUE(a.response_data, '$.dynamicOrchestratorResponse.lives[1].attributes.attributes.IS_INSURED'),'N/A') AS IS_INSURED_LIFE2,
--UW_TYPE_INSURED & UW_TYPE_OWNER--
NVL(JSON_VALUE(a.response_data, '$.dynamicOrchestratorResponse.lives[0].attributes.attributes.UW_TYPE'),'N/A') AS UW_TYPE_INSURED,
NVL(JSON_VALUE(a.response_data, '$.dynamicOrchestratorResponse.lives[1].attributes.attributes.UW_TYPE'),'N/A') AS UW_TYPE_OWNER,
--HEIGHT_INSURED & HEIGHT_OWNER--
NVL(JSON_VALUE(a.response_data, '$.dynamicOrchestratorResponse.lives[0].attributes.attributes.HEIGHT'),'N/A') AS HEIGHT_INSURED,
NVL(JSON_VALUE(a.response_data, '$.dynamicOrchestratorResponse.lives[1].attributes.attributes.HEIGHT'),'N/A') AS HEIGHT_OWNER,
NVL(JSON_VALUE(a.response_data, '$.dynamicOrchestratorResponse.lives[0].attributes.attributes.ANS_HEIGHT'),'N/A') AS ANS_HEIGHT_INSURED,
NVL(JSON_VALUE(a.response_data, '$.dynamicOrchestratorResponse.lives[1].attributes.attributes.ANS_HEIGHT'),'N/A') AS ANS_HEIGHT_OWNER,
--WEIGHT_INSURED & WEIGHT_OWNER--
NVL(JSON_VALUE(a.response_data, '$.dynamicOrchestratorResponse.lives[0].attributes.attributes.WEIGHT'),'N/A') AS WEIGHT_INSURED,
NVL(JSON_VALUE(a.response_data, '$.dynamicOrchestratorResponse.lives[1].attributes.attributes.WEIGHT'),'N/A') AS WEIGHT_OWNER,
NVL(JSON_VALUE(a.response_data, '$.dynamicOrchestratorResponse.lives[0].attributes.attributes.ANS_WEIGHT'),'N/A') AS ANS_WEIGHT_INSURED,
NVL(JSON_VALUE(a.response_data, '$.dynamicOrchestratorResponse.lives[1].attributes.attributes.ANS_WEIGHT'),'N/A') AS ANS_WEIGHT_OWNER,
--BMI
NVL(JSON_VALUE(a.response_data, '$.dynamicOrchestratorResponse.lives[0].attributes.attributes.BMI'),'N/A') AS BMI_INSURED,
--CLI_SMKR_CD INSURED 
NVL(JSON_VALUE(a.response_data, '$.dynamicOrchestratorResponse.lives[0].attributes.attributes.CLI_SMKR_CD'),'N/A') AS CLI_SMKR_CD_INSURED,

--GENDER INSURED & OWNER
NVL(JSON_VALUE(a.response_data, '$.dynamicOrchestratorResponse.lives[0].attributes.attributes.GENDER'),'N/A') AS GENDER_INSURED,
NVL(JSON_VALUE(a.response_data, '$.dynamicOrchestratorResponse.lives[1].attributes.attributes.GENDER'),'N/A') AS GENDER_OWNER,
--AGE LIFE1 & LIFE2
  NVL(JSON_VALUE(a.response_data, '$.dynamicOrchestratorResponse.lives[0].attributes.attributes.AGE'),'N/A') AS Age_INSURED,
  NVL(JSON_VALUE(a.response_data, '$.dynamicOrchestratorResponse.lives[1].attributes.attributes.AGE'),'N/A') AS Age_OWNER,

--CLI_INS_REFUS_IND_INSURED & OWNER
  NVL(JSON_VALUE(a.response_data, '$.dynamicOrchestratorResponse.lives[0].attributes.attributes.CLI_INS_REFUS_IND'),'N/A') AS CLI_INS_REFUS_IND_INSURED,
  NVL(JSON_VALUE(a.response_data, '$.dynamicOrchestratorResponse.lives[1].attributes.attributes.CLI_INS_REFUS_IND'),'N/A') AS CLI_INS_REFUS_IND_OWNER,
--CLI_CARDIO_SYS_IND INSURED & OWNER
--updated CLI_CARDIO_SYS_IND
 NVL(JSON_VALUE(a.response_data, '$.dynamicOrchestratorResponse.lives[0].attributes.attributes.CLI_CARDIO_SYS_IND'),'N/A') AS CLI_CARDIO_SYS_IND_INSURED,
  NVL(JSON_VALUE(a.response_data, '$.dynamicOrchestratorResponse.lives[1].attributes.attributes.CLI_CARDIO_SYS_IND'),'N/A') AS CLI_CARDIO_SYS_IND_OWNER,
--RCNT_HOSP_ADMT_IND INSURED & OWNER
 NVL(JSON_VALUE(a.response_data, '$.dynamicOrchestratorResponse.lives[0].attributes.attributes.RCNT_HOSP_ADMT_IND'),'N/A') AS RCNT_HOSP_ADMT_IND_INSURED,
  NVL(JSON_VALUE(a.response_data, '$.dynamicOrchestratorResponse.lives[1].attributes.attributes.RCNT_HOSP_ADMT_IND'),'N/A') AS RCNT_HOSP_ADMT_IND_OWNER,
--ANS_TEMP_LIFE_Q1_TXT INSURED & OWNER
NVL(JSON_VALUE(a.response_data,'$.dynamicOrchestratorResponse.lives[0].attributes.attributes.ANS_TEMP_LIFE_Q1_TXT'),'N/A') AS ANS_TEMP_LIFE_Q1_TXT_INSURED,

--ANS_TEMP_LIFE_Q2_TXT_INSURED & OWNER
NVL(JSON_VALUE(a.response_data,'$.dynamicOrchestratorResponse.lives[0].attributes.attributes.ANS_TEMP_LIFE_Q2_TXT'),'N/A') AS ANS_TEMP_LIFE_Q2_TXT_INSURED,

 --ANS_TEMP_LIFE_Q3_TXT INSURED & OWNER
 --updated to Q3
NVL(JSON_VALUE(a.response_data,'$.dynamicOrchestratorResponse.lives[0].attributes.attributes.ANS_TEMP_LIFE_Q3_TXT'),'N/A') AS ANS_TEMP_LIFE_Q3_TXT_INSURED,
 --MEDICAL_DISCLOSED_INSURED & OWNER
NVL(JSON_VALUE(a.response_data,'$.dynamicOrchestratorResponse.lives[0].attributes.attributes.MEDICAL_DISCLOSED'),'N/A') AS MEDICAL_DISCLOSED_INSURED,
NVL(JSON_VALUE(a.response_data,'$.dynamicOrchestratorResponse.lives[1].attributes.attributes.MEDICAL_DISCLOSED'),'N/A') AS MEDICAL_DISCLOSED_OWNER,

 --TOTAL_UW_AMT_CI INSURED & OWNER
NVL(JSON_VALUE(a.response_data,'$.dynamicOrchestratorResponse.lives[0].attributes.attributes.TOTAL_UW_AMT_CI'),'N/A') AS TOTAL_UW_AMT_CI_INSURED,
NVL(JSON_VALUE(a.response_data,'$.dynamicOrchestratorResponse.lives[1].attributes.attributes.TOTAL_UW_AMT_CI'),'N/A') AS TOTAL_UW_AMT_CI_TXT_OWNER,

--TOTAL_PREMIUM_LOADING_INSURED & OWNER
NVL(
    REPLACE(
        REPLACE(
            JSON_QUERY(a.response_data, '$.dynamicOrchestratorResponse.lives[0].attributes.riskBasedAttributes.TOTAL_PREMIUM_LOADING' RETURNING VARCHAR2(4000)),
                '{', ''
            ),
            '}', ''
        ),
        'N/A'
    ) AS total_premium_loading_insured,
NVL(
    REPLACE(
        REPLACE(
            JSON_QUERY(a.response_data, '$.dynamicOrchestratorResponse.lives[1].attributes.riskBasedAttributes.TOTAL_PREMIUM_LOADING' RETURNING VARCHAR2(4000)),
                '{', ''
            ),
            '}', ''
        ),
        'N/A'
    ) AS total_premium_loading_owner,
--InsuredRiskType & RiskTypeStatus INSURED & OWNER
    NVL((SELECT LISTAGG(NVL(xml_data.riskType, 'No Risk Type'), ', ' || CHR(10)) WITHIN GROUP (ORDER BY NULL)
            FROM XMLTABLE(
                     '/IUM/IUMRequest/Client[1]/autoUnderwritingDecisionByRiskType'
                     PASSING XMLTYPE(l.request_data)
                     COLUMNS riskType VARCHAR2(255) PATH 'riskType'
                 ) xml_data
            WHERE l.app_id = hdr.app_id
       ), 'No Risk Types') AS InsuredRiskType,
       NVL((SELECT LISTAGG(NVL(xml_data.decision, 'No Decision'), ', ' || CHR(10)) WITHIN GROUP (ORDER BY NULL)
            FROM XMLTABLE(
                     '/IUM/IUMRequest/Client[1]/autoUnderwritingDecisionByRiskType'
                     PASSING XMLTYPE(l.request_data)
                     COLUMNS decision VARCHAR2(255) PATH 'decision'
                 ) xml_data
            WHERE l.app_id = hdr.app_id
       ), 'No Decision') AS InsuredRiskTypeStatus,
--OWNER RiskType & RiskTypeStatus INSURED & OWNER
       NVL((SELECT LISTAGG(NVL(xml_data.riskType, 'No Risk Type'), ', ' || CHR(10)) WITHIN GROUP (ORDER BY NULL)
            FROM XMLTABLE(
                     '/IUM/IUMRequest/Client[2]/autoUnderwritingDecisionByRiskType'
                     PASSING XMLTYPE(l.request_data)
                     COLUMNS riskType VARCHAR2(255) PATH 'riskType'
                 ) xml_data
            WHERE l.app_id = hdr.app_id
       ), 'No Risk Types') AS OwnerRiskType,
       NVL((SELECT LISTAGG(NVL(xml_data.decision, 'No Decision'), ', ' || CHR(10)) WITHIN GROUP (ORDER BY NULL)
            FROM XMLTABLE(
                     '/IUM/IUMRequest/Client[2]/autoUnderwritingDecisionByRiskType'
                     PASSING XMLTYPE(l.request_data)
                     COLUMNS decision VARCHAR2(255) PATH 'decision'
                 ) xml_data
            WHERE l.app_id = hdr.app_id
       ), 'No Decision') AS OwnerRiskTypeStatus,
    --KO INSURED     
      NVL(
        (SELECT LISTAGG(DISTINCT jt.description, ', ' || CHR(10)) 
                WITHIN GROUP (ORDER BY jt.description)
         FROM JSON_TABLE(
                  a.response_data,
                  '$.dynamicOrchestratorResponse.lives[0].results.autoResultsPerRiskType[*].triggers[*]'
                  COLUMNS (
                      description VARCHAR2(2000) PATH '$.description'
                  )
              ) jt
        ), 'N/A') AS KO_INSURED,
    --KO OWNER   
    NVL(
        (SELECT LISTAGG(DISTINCT jt.description, ', ' || CHR(10)) 
                WITHIN GROUP (ORDER BY jt.description)
         FROM JSON_TABLE(
                  a.response_data,
                  '$.dynamicOrchestratorResponse.lives[1].results.autoResultsPerRiskType[*].triggers[*]'
                  COLUMNS (
                      description VARCHAR2(2000) PATH '$.description'
                  )
              ) jt
        ), 'N/A') AS KO_OWNER

FROM 
    latest_hdr hdr
LEFT JOIN 
    latest_stpautoappdo a ON hdr.app_id = a.app_id AND a.rn = 1
LEFT JOIN 
    latest_stpupdium l ON hdr.app_id = l.app_id AND l.rn = 1
WHERE 
    hdr.rn = 1  
    AND hdr.mre_case_id IS NOT NULL 
    AND hdr.updated_dt BETWEEN TO_DATE('2025-06-02 11:00:00', 'YYYY-MM-DD HH24:MI:SS') 
                     AND TO_DATE('2025-06-03 11:00:00', 'YYYY-MM-DD HH24:MI:SS')
ORDER BY 
    hdr.updated_dt DESC