WITH latest_hdr AS (
    SELECT app_id, reference_no, owner_client_no, insured_client_no, mre_case_id,status, updated_dt,
           ROW_NUMBER() OVER (PARTITION BY app_id ORDER BY updated_dt DESC) AS rn
    FROM STP_TRANSACTION_HDR
),
latest_stpselpoling2 AS (   
    SELECT app_id, response_data, updated_dt,
           ROW_NUMBER() OVER (PARTITION BY app_id ORDER BY updated_dt DESC) AS rn
    FROM STP_TRANSACTION_DTL
    WHERE activity_cd = 'STPSELPOLING2'
),
latest_stpupuwding AS (
    SELECT app_id, request_data, updated_dt,
           ROW_NUMBER() OVER (PARTITION BY app_id ORDER BY updated_dt DESC) AS rn
    FROM STP_TRANSACTION_DTL
    WHERE activity_cd = 'STPUPDUWDING'
),
latest_stpautoappdo AS (
    SELECT app_id,response_data,updated_dt,
            ROW_NUMBER() OVER (PARTITION BY app_id ORDER BY updated_dt DESC) as rn
    FROM STP_TRANSACTION_DTL
    WHERE ACTIVITY_CD='STPAUTOAPPDO'
),
latest_stpupdium AS (
    SELECT app_id, request_data,updated_dt,
           ROW_NUMBER() OVER (PARTITION BY app_id ORDER BY updated_dt DESC) AS rn
    FROM stp_transaction_dtl
    WHERE activity_cd = 'STPUPDDRTIUM'
)

SELECT 
    hdr.app_id, 
    hdr.reference_no,
    hdr.owner_client_no,
    hdr.insured_client_no,
    hdr.mre_case_id,
    hdr.updated_dt,
    --PO_RISK_RATING
     NVL(JSON_VALUE(audo.response_data, '$.dynamicOrchestratorResponse.attributes.attributes.PO_RISK_RATING'),'N/A') AS PO_RISK_RATING,
    --PO_RISK_RATING_MATCH_TYPE
     NVL(JSON_VALUE(audo.response_data, '$.dynamicOrchestratorResponse.attributes.attributes.PO_RISK_RATING_MATCH_TYPE'),'N/A') AS PO_RISK_RATING_MATCH_TYPE,
    --MIRPOLSUPRESISSIND
    NVL(
        REGEXP_SUBSTR(
            DBMS_LOB.SUBSTR(upuw.request_data, 4000, 1),
            '<MirPolSupresIssIndT>([^<]+)</MirPolSupresIssIndT>',
            1, 1, NULL, 1
        ), 'N/A'
    ) AS suppress_indicator,
    
    --InsuredRiskType & RiskTypeStatus INSURED & OWNER
    NVL((SELECT LISTAGG(NVL(xml_data.riskType, 'No Risk Type'), ', ' || CHR(10)) WITHIN GROUP (ORDER BY NULL)
            FROM XMLTABLE(
                     '/IUM/IUMRequest/Client[1]/autoUnderwritingDecisionByRiskType'
                     PASSING XMLTYPE(updi.request_data)
                     COLUMNS riskType VARCHAR2(255) PATH 'riskType'
                 ) xml_data
            WHERE updi.app_id = hdr.app_id
       ), 'No Risk Types') AS InsuredRiskType,
       NVL((SELECT LISTAGG(NVL(xml_data.decision, 'No Decision'), ', ' || CHR(10)) WITHIN GROUP (ORDER BY NULL)
            FROM XMLTABLE(
                     '/IUM/IUMRequest/Client[1]/autoUnderwritingDecisionByRiskType'
                     PASSING XMLTYPE(updi.request_data)
                     COLUMNS decision VARCHAR2(255) PATH 'decision'
                 ) xml_data
            WHERE updi.app_id = hdr.app_id
       ), 'No Decision') AS InsuredRiskTypeStatus,
--OWNER RiskType & RiskTypeStatus INSURED & OWNER
       NVL((SELECT LISTAGG(NVL(xml_data.riskType, 'No Risk Type'), ', ' || CHR(10)) WITHIN GROUP (ORDER BY NULL)
            FROM XMLTABLE(
                     '/IUM/IUMRequest/Client[2]/autoUnderwritingDecisionByRiskType'
                     PASSING XMLTYPE(updi.request_data)
                     COLUMNS riskType VARCHAR2(255) PATH 'riskType'
                 ) xml_data
            WHERE updi.app_id = hdr.app_id
       ), 'No Risk Types') AS OwnerRiskType,
       NVL((SELECT LISTAGG(NVL(xml_data.decision, 'No Decision'), ', ' || CHR(10)) WITHIN GROUP (ORDER BY NULL)
            FROM XMLTABLE(
                     '/IUM/IUMRequest/Client[2]/autoUnderwritingDecisionByRiskType'
                     PASSING XMLTYPE(updi.request_data)
                     COLUMNS decision VARCHAR2(255) PATH 'decision'
                 ) xml_data
            WHERE updi.app_id = hdr.app_id
       ), 'No Decision') AS OwnerRiskTypeStatus,
    --KO INSURED     
      NVL(
        (SELECT LISTAGG(DISTINCT jt.description, ', ' || CHR(10)) 
                WITHIN GROUP (ORDER BY jt.description)
         FROM JSON_TABLE(
                  audo.response_data,
                      '$.dynamicOrchestratorResponse.lives[0].results.autoResultsPerRiskType[*].triggers[*]'
                  COLUMNS (
                      description VARCHAR2(2000) PATH '$.description'
                  )
              ) jt
        ), 'N/A') AS KO_INSURED,
    --KO OWNER   
    NVL(
        (SELECT LISTAGG(DISTINCT jt.description, ', ' || CHR(10)) 
                WITHIN GROUP (ORDER BY jt.description)
         FROM JSON_TABLE(
                  audo.response_data,
                  '$.dynamicOrchestratorResponse.lives[1].results.autoResultsPerRiskType[*].triggers[*]'
                  COLUMNS (
                      description VARCHAR2(2000) PATH '$.description'
                  )
              ) jt
        ), 'N/A') AS KO_OWNER,
    --GAP STATUS
    hdr.status AS GAP_STATUS,
    -- Extract policy status using regexp - ALWAYS use DBMS_LOB.SUBSTR with CLOBs
    NVL(
        REGEXP_SUBSTR(
        DBMS_LOB.SUBSTR(elpo.response_data, 2000, 1),
        '<MirPolCstatCd>([^<]+)</MirPolCstatCd>',
        1, 1, NULL, 1
    ) ,'N/A'
    ) AS policy_status
    
FROM 
    latest_hdr hdr
LEFT JOIN 
    latest_stpselpoling2 elpo ON hdr.app_id = elpo.app_id AND elpo.rn = 1
LEFT JOIN 
    latest_stpupuwding upuw ON hdr.app_id = upuw.app_id AND upuw.rn = 1
LEFT JOIN
    latest_stpautoappdo audo ON hdr.app_id = audo.app_id and audo.rn = 1
LEFT JOIN
    latest_stpupdium updi ON hdr.app_id = updi.app_id AND updi.rn = 1

WHERE   
    hdr.rn = 1  
    AND hdr.mre_case_id IS NOT NULL 
    AND REGEXP_SUBSTR(
        DBMS_LOB.SUBSTR(upuw.request_data, 2000, 1),
        '<MirPolSupresIssIndT>([^<]+)</MirPolSupresIssIndT>',
        1, 1, NULL, 1
    ) = 'N'
    AND hdr.updated_dt BETWEEN TO_DATE('2025-06-02 11:00:00', 'YYYY-MM-DD HH24:MI:SS') 
                       AND TO_DATE('2025-06-03 11:00:00', 'YYYY-MM-DD HH24:MI:SS')
ORDER BY hdr.updated_dt DESC