WITH latest_stpautoappdo AS (
    SELECT app_id, response_data, updated_dt,
           ROW_NUMBER() OVER (PARTITION BY app_id ORDER BY updated_dt DESC) AS rn
    FROM stp_transaction_dtl
    WHERE activity_cd = 'STPAUTOAPPDO'
),
latest_stpcrecasmre AS (
    SELECT app_id, response_data, updated_dt,
           ROW_NUMBER() OVER (PARTITION BY app_id ORDER BY created_dt DESC) AS rn
    FROM stp_transaction_dtl
    WHERE activity_cd = 'STPCRECASMRE'
),
latest_hdr AS (
    SELECT app_id, reference_no, mre_case_id, updated_dt,
           ROW_NUMBER() OVER (PARTITION BY app_id ORDER BY updated_dt DESC) AS rn
    FROM STP_TRANSACTION_HDR
)
SELECT hdr.app_id, hdr.reference_no,
    --MRE CASE ID 
       COALESCE(JSON_VALUE(c.response_data, '$.response.caseId'), hdr.mre_case_id) AS LatestCaseId, hdr.updated_dt AS updated_dt,
    --AGE LIFE  
       NVL(JSON_VALUE(a.response_data, '$.dynamicOrchestratorResponse.lives[0].attributes.attributes.AGE'),'N/A') AS Age_Life_0,
    --Insured Risk Type
       NVL(
           (SELECT LISTAGG(NVL(jt.autoResultsRiskTypeDescription, 'No Description'), ', ' || CHR(10)) 
                   WITHIN GROUP (ORDER BY jt.autoResultsRiskTypeDescription)
            FROM JSON_TABLE(
                     (SELECT response_data FROM latest_stpautoappdo WHERE app_id = hdr.app_id AND rn = 1),
                     '$.dynamicOrchestratorResponse.lives[*].results.autoResultsPerRiskType[*]'
                     COLUMNS (
                         autoResultsRiskTypeDescription VARCHAR2(255) PATH '$.riskType.description'
                     )
                 ) jt
            WHERE jt.autoResultsRiskTypeDescription IS NOT NULL
              AND EXISTS (
                  SELECT 1
                  FROM JSON_TABLE(
                           (SELECT response_data FROM latest_stpautoappdo WHERE app_id = hdr.app_id AND rn = 1),
                           '$.dynamicOrchestratorResponse.lives[*]'
                           COLUMNS (
                               fullName VARCHAR2(255) PATH '$.fullName'
                           )
                       ) jt_life
                  WHERE jt_life.fullName = 'life[1]'
              )
           ), 'No Description') AS insuredRiskType ,
--Insured Risk Type Status
            NVL(
           (SELECT LISTAGG(NVL(jt.autoResultsRiskTypeDescription, 'No Description'), ', ' || CHR(10)) 
                   WITHIN GROUP (ORDER BY jt.autoResultsRiskTypeDescription)
            FROM JSON_TABLE(
                     (SELECT response_data FROM latest_stpautoappdo WHERE app_id = hdr.app_id AND rn = 1),
                     '$.dynamicOrchestratorResponse.lives[*].results.autoResultsPerRiskType[*]'
                     COLUMNS (
                         autoResultsRiskTypeDescription VARCHAR2(255) PATH '$.underwritingStatus.description'
                     )
                 ) jt
            WHERE jt.autoResultsRiskTypeDescription IS NOT NULL
              AND EXISTS (
                  SELECT 1
                  FROM JSON_TABLE(
                           (SELECT response_data FROM latest_stpautoappdo WHERE app_id = hdr.app_id AND rn = 1),
                           '$.dynamicOrchestratorResponse.lives[*]'
                           COLUMNS (
                               fullName VARCHAR2(255) PATH '$.fullName'
                           )
                       ) jt_life
                  WHERE jt_life.fullName = 'life[1]'
              )
           ), 'No Description') AS insuredRiskTypeStatus ,
--Owner Risk Type
       NVL(
           (SELECT LISTAGG(NVL(jt.autoResultsRiskTypeDescription, 'No Description'), ', ' || CHR(10)) 
                   WITHIN GROUP (ORDER BY jt.autoResultsRiskTypeDescription)
            FROM JSON_TABLE(
                     (SELECT response_data FROM latest_stpautoappdo WHERE app_id = hdr.app_id AND rn = 1),
                     '$.dynamicOrchestratorResponse.lives[*].results.autoResultsPerRiskType[*]'
                     COLUMNS (
                         autoResultsRiskTypeDescription VARCHAR2(255) PATH '$.riskType.description'
                     )
                 ) jt
            WHERE jt.autoResultsRiskTypeDescription IS NOT NULL
              AND EXISTS (
                  SELECT 1
                  FROM JSON_TABLE(
                           (SELECT response_data FROM latest_stpautoappdo WHERE app_id = hdr.app_id AND rn = 1),
                           '$.dynamicOrchestratorResponse.lives[*]'
                           COLUMNS (
                               fullName VARCHAR2(255) PATH '$.fullName'
                           )
                       ) jt_life
                  WHERE jt_life.fullName = 'life[2]'
              )
           ), 'No Description') AS ownerRiskType ,
--Owner Risk Type Status           
            NVL(
           (SELECT LISTAGG(NVL(jt.autoResultsRiskTypeDescription, 'No Description'), ', ' || CHR(10)) 
                   WITHIN GROUP (ORDER BY jt.autoResultsRiskTypeDescription)
            FROM JSON_TABLE(
                     (SELECT response_data FROM latest_stpautoappdo WHERE app_id = hdr.app_id AND rn = 1),
                     '$.dynamicOrchestratorResponse.lives[*].results.autoResultsPerRiskType[*]'
                     COLUMNS (
                         autoResultsRiskTypeDescription VARCHAR2(255) PATH '$.underwritingStatus.description'
                     )
                 ) jt
               WHERE jt.autoResultsRiskTypeDescription IS NOT NULL
              AND EXISTS (
                  SELECT 1
                  FROM JSON_TABLE(
                           (SELECT response_data FROM latest_stpautoappdo WHERE app_id = hdr.app_id AND rn = 1),
                           '$.dynamicOrchestratorResponse.lives[*]'
                           COLUMNS (
                               fullName VARCHAR2(255) PATH '$.fullName'
                           )
                       ) jt_life
                  WHERE jt_life.fullName = 'life[2]'
              )
           ), 'No Description') AS ownerRiskTypeStatus,
    --KO INSURED     
     NVL(JSON_VALUE(a.response_data, '$.dynamicOrchestratorResponse.lives[0].results.autoResultsPerRiskType[0].triggers[0].description'),'N/A') AS KO_INSURED,
    --KO OWNER   
     NVL(JSON_VALUE(a.response_data, '$.dynamicOrchestratorResponse.lives[0].results.autoResultsPerRiskType[0].triggers[0].description'),'N/A') AS KO_OWNER,
    --TOTAL_UW_INSURED
     NVL(JSON_VALUE(a.response_data, '$.dynamicOrchestratorResponse.lives[0].attributes.attributes.TOTAL_UW_AMT_BASIC'),'N/A') AS TOTAL_UW_AMT_BASIC_INSURED,
     NVL(JSON_VALUE(a.response_data, '$.dynamicOrchestratorResponse.lives[0].attributes.attributes.TOTAL_UW_AMT_HIB'),'N/A') AS TOTAL_UW_AMT_HIB_INSURED,
     NVL(JSON_VALUE(a.response_data, '$.dynamicOrchestratorResponse.lives[0].attributes.attributes.TOTAL_UW_AMT_CI'),'N/A') AS TOTAL_UW_AMT_CI_INSURED,
         NVL(JSON_VALUE(a.response_data, '$.dynamicOrchestratorResponse.lives[0].attributes.attributes.TOTAL_UW_AMT_FCIM'),'N/A') AS TOTAL_UW_AMT_FCIM_INSURED,
     NVL(JSON_VALUE(a.response_data, '$.dynamicOrchestratorResponse.lives[0].attributes.attributes.TOTAL_UW_AMT_CANCER'),'N/A') AS TOTAL_UW_AMT_CANCER_INSURED,
     --TOTAL_MORBIDITY -- TOTAL_UW_AMT_HIB + TOTAL_UW_AMT_CI + TOTAL_UW_AMT_FCIM + TOTAL_UW_AMT_CANCER
    NVL(
        JSON_VALUE(a.response_data, '$.dynamicOrchestratorResponse.lives[0].attributes.attributes.TOTAL_UW_AMT_HIB'), 0
    ) +
    NVL(
        JSON_VALUE(a.response_data, '$.dynamicOrchestratorResponse.lives[0].attributes.attributes.TOTAL_UW_AMT_CI'), 0
    ) +
    NVL(
        JSON_VALUE(a.response_data, '$.dynamicOrchestratorResponse.lives[0].attributes.attributes.TOTAL_UW_AMT_FCIM'), 0
    ) +
    NVL(
        JSON_VALUE(a.response_data, '$.dynamicOrchestratorResponse.lives[0].attributes.attributes.TOTAL_UW_AMT_CANCER '), 0
    ) AS TOTAL_MORBIDITY
         
FROM latest_hdr hdr
LEFT JOIN latest_stpcrecasmre c ON hdr.app_id = c.app_id AND c.rn = 1
LEFT JOIN latest_stpautoappdo a ON hdr.app_id = a.app_id AND a.rn = 1
WHERE hdr.rn = 1 and hdr.updated_dt > '02-FEB-25';