WITH latest_stpupdium AS (
    SELECT app_id, request_data,
           ROW_NUMBER() OVER (PARTITION BY app_id ORDER BY created_dt DESC) AS rn
    FROM stp_transaction_dtl
    WHERE activity_cd = 'STPUPDDRTIUM'
),
latest_stpcheckelig AS (
    SELECT app_id, response_data,
           ROW_NUMBER() OVER (PARTITION BY app_id ORDER BY created_dt DESC) AS rn
    FROM stp_transaction_dtl
    WHERE activity_cd = 'STPCHECKELIG'
),
latest_stpcrecasmre AS (
    SELECT app_id, response_data, created_dt,
           ROW_NUMBER() OVER (PARTITION BY app_id ORDER BY created_dt DESC) AS rn
    FROM stp_transaction_dtl
    WHERE activity_cd = 'STPCRECASMRE'
),
latest_hdr AS (
    SELECT app_id, reference_no, mre_case_id, created_dt,
           ROW_NUMBER() OVER (PARTITION BY app_id ORDER BY created_dt DESC) AS rn
    FROM STP_TRANSACTION_HDR
)
SELECT hdr.app_id, hdr.reference_no, 
       c.created_dt AS latest_created_dt,
       NVL(COALESCE(JSON_VALUE(c.response_data, '$.response.caseId'), hdr.mre_case_id),'N/A') AS LatestCaseId,
       NVL((SELECT LISTAGG(NVL(xml_data.riskType, 'No Risk Type'), ', ' || CHR(10)) WITHIN GROUP (ORDER BY NULL)
            FROM XMLTABLE(
                     '/IUM/IUMRequest/Client[1]/autoUnderwritingDecisionByRiskType'
                     PASSING XMLTYPE(l.request_data)
                     COLUMNS riskType VARCHAR2(255) PATH 'riskType'
                 ) xml_data
            WHERE l.app_id = hdr.app_id
       ), 'No Risk Types') AS InsuredRiskType,
       NVL((SELECT LISTAGG(NVL(xml_data.decision, 'No Decision'), ', ' || CHR(10)) WITHIN GROUP (ORDER BY NULL)
            FROM XMLTABLE(
                     '/IUM/IUMRequest/Client[1]/autoUnderwritingDecisionByRiskType'
                     PASSING XMLTYPE(l.request_data)
                     COLUMNS decision VARCHAR2(255) PATH 'decision'
                 ) xml_data
            WHERE l.app_id = hdr.app_id
       ), 'No Decision') AS InsuredRiskTypeStatus,
       NVL((SELECT LISTAGG(NVL(xml_data.riskType, 'No Risk Type'), ', ' || CHR(10)) WITHIN GROUP (ORDER BY NULL)
            FROM XMLTABLE(
                     '/IUM/IUMRequest/Client[2]/autoUnderwritingDecisionByRiskType'
                     PASSING XMLTYPE(l.request_data)
                     COLUMNS riskType VARCHAR2(255) PATH 'riskType'
                 ) xml_data
            WHERE l.app_id = hdr.app_id
       ), 'No Risk Types') AS OwnerRiskType,
       NVL((SELECT LISTAGG(NVL(xml_data.decision, 'No Decision'), ', ' || CHR(10)) WITHIN GROUP (ORDER BY NULL)
            FROM XMLTABLE(
                     '/IUM/IUMRequest/Client[2]/autoUnderwritingDecisionByRiskType'
                     PASSING XMLTYPE(l.request_data)
                     COLUMNS decision VARCHAR2(255) PATH 'decision'
                 ) xml_data
            WHERE l.app_id = hdr.app_id
       ), 'No Decision') AS OwnerRiskTypeStatus,
       NVL((SELECT JSON_VALUE(e.response_data, '$.eligibilityCheckResponse.data.elig_check_val_result') 
            FROM latest_stpcheckelig e
            WHERE e.app_id = hdr.app_id AND e.rn = 1), 'N/A') AS EligCheckValResult,
       NVL((SELECT JSON_VALUE(e.response_data, '$.eligibilityCheckResponse.data.elig_check_val_error_field') 
            FROM latest_stpcheckelig e
            WHERE e.app_id = hdr.app_id AND e.rn = 1), 'N/A') AS EligCheckValErrorField
FROM latest_hdr hdr
LEFT JOIN latest_stpupdium l ON hdr.app_id = l.app_id AND l.rn = 1
LEFT JOIN latest_stpcrecasmre c ON hdr.app_id = c.app_id AND c.rn = 1
WHERE hdr.created_dt BETWEEN TO_TIMESTAMP('08-APR-24 08:00:00.000000000', 'DD-MON-RR HH24:MI:SS.FF9')  
                        AND TO_TIMESTAMP('30-APR-24 23:59:59.999999999', 'DD-MON-RR HH24:MI:SS.FF9');